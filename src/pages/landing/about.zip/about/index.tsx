import { useEffect, useState } from "react";
import { useSpring , animated } from "react-spring";
import aboutImage from "../../../assets/images/new_bg.png";
import gameDashboard from "../../../assets/images/GAME DASHBOARD.png";
import walletDashboard from "../../../assets/images/wallet.png";
import invImage from "../../../assets/images/inventory.png"
import dex from '../../../assets/images/dex.png'
import launchpad2 from '../../../assets/images/Launchpad2.png'
import cex from '../../../assets/images/cex.png'
import box from "../../../assets/images/about1.png";
import launchpad1 from '../../../assets/images/launchpad1.png';
import stalking from '../../../assets/images/stalking.png';
import nftfeature from '../../../assets/images/nftfeature.png';
import nftmarket from '../../../assets/images/nftmarket.png';
import tokenroom from '../../../assets/images/tokenroom.png';
import p2pmarket from '../../../assets/images/p2pmarket.png';
import bg from '../../../assets/images/bottom_blur.png'
import bgArea from '../../../assets/images/bg.png'
import "./index.css"
import NavPill from "./Pill/NavPill";
import FirstAnimation from "./Animations/FirstAnimation";
import redLeft from '../../../assets/planets/red-left.png';
import redRight from '../../../assets/planets/red-right.png'
import redSmall from '../../../assets/planets/red-sm-mid.png'
import redDot from '../../../assets/planets/red-dot.png'
import blueRight from '../../../assets/planets/blue-planet-left.png'
import blueFull from '../../../assets/planets/blue-planet-full.png'
import blueSplash from '../../../assets/planets/splash.png'
import blueDot from '../../../assets/planets/small-ball.png'

const DonutCircle = () => {
  const [fadeIn , setFadeIn ] = useState(false);
  
  useEffect(() => {
    setTimeout(() => {
       setFadeIn(true);
    }, 7000)
  } , []);

  const props = useSpring({
    to: {opacity: 0},
    from: {opacity: 1},
    reverse: fadeIn,
    delay: 300
  })

  // const names = [{ name: gameDashboard }, { name: walletDashboard }, { name: invImage }, { name: dex }, { name: launchpad1 }, { name: cex }, { name: launchpad2 }, { name: stalking }, { name: tokenroom }, { name: nftmarket }, { name: nftfeature }, { name: p2pmarket }]

  return (<>

    <div className="relative h-[155vh]" id="about">
      <div className="absolute w-full h-full inset-0 bg-fixed bg-cover bg-no-repeat filter blur-3" style={{ backgroundImage: `url(${bg})` }}>
      </div>
      <FirstAnimation />
      {/* <SecondAnimation /> */}
      <div className={`relative z-10 pb-5 ${fadeIn ? '' : 'hidden' }`}>   
       <animated.div style={fadeIn ? props : {}}> 
        <div>
          <h1 className="text-white text-center font-poppins text-6xl font-semibold relative">
            About Us
          </h1>
          <br />
          <br />
          <p className="text-white text-center font-poppins text-lg font-normal leading-10">Providing everything you need to play and create</p>
        </div>

        {/* NavPill AREA */}
        <div className="absolute">
    <img className="relative h-[314.971px] z-0 top-[25vh]" src={redLeft} />
    <img className="w-[131.381px] h-[130.282px] relative top-[61vh] left-[20vw]" src={redSmall} />
    <img className="relative w-[71px] h-[70px] bottom-[38vh] left-[17vw]" src={redDot} />
    <img className="relative w-[74px] h-[73px] bottom-[52vh] left-[75vw]" src={redDot} />
    <img className="relative z-0 left-[76vw] top-[51vh]" src={redRight} />
</div>
<NavPill />
<div className="absolute">
    <img className="relative left-[80vw] bottom-[97vh]" src={blueFull} />
    <img className="relative w-[68.791px] h-[67px] bottom-[90vh] left-[4vw]" src={blueDot} />
    <img className="relative right-[-34vw] z-0" src={blueFull} />
    <img className="relative w-[125.983px] h-[125.31px] bottom-[32vh] left-[52vw]" src={blueSplash} />
    <img className="relative w-[68.791px] h-[67px] bottom-[40vh] left-[68vw]" src={blueDot} />
    <img className="relative w-[39.016px] h-[38px] bottom-[60vh] left-[72vw]" src={blueDot} />
    <img className="relative w-[39.016px] h-[38px] bottom-[75vh] left-[81vw]" src={blueDot} />
    <img className="relative z-0 bottom-[105vh] left-[85vw]" src={blueRight} />
</div>


        {/* NavPill AREA END */}


</animated.div>
      </div>
    </div>
  </>);
};

export default DonutCircle;

