import React, { useState, useEffect } from 'react';
import play from '../../../../assets/images/play-console-up.png';
import './animation.css';
import playUnlock from '../../../../assets/images/unlock-play.png';
import redLeft from '../../../../assets/planets/red-left.png';
import redRight from '../../../../assets/planets/red-right.png'
import redSmall from '../../../../assets/planets/red-sm-mid.png'
import redDot from '../../../../assets/planets/red-dot.png'
import blueRight from '../../../../assets/planets/blue-planet-left.png'
import blueFull from '../../../../assets/planets/blue-planet-full.png'
import blueSplash from '../../../../assets/planets/splash.png'
import blueDot from '../../../../assets/planets/small-ball.png'


function FirstAnimation() {
    const [startAnimation, setStartAnimation] = useState(false);
    const [endAnimation, setEndAnimation] = useState(false);
    const [startSecondAnimation, setStartSecondAnimation] = useState(false);
    const [endSecondAnimation, setSecondEndAnimation] = useState(false);
    const [redPlanetsFade, setRedPlanetsFade] = useState(false);
    const [bluePlanetsFade, setBluePlanetsFade] = useState(false);
    // FIRST ANIMATIONS START
    useEffect(() => {
        const animationTimeout = setTimeout(() => {
            setStartAnimation(true);
        }, 2000);

        return () => {
            clearTimeout(animationTimeout);
        };
    }, []);

    //   RED PLANETS START ANIMATION

    useEffect(() => {
        if (startAnimation) {
            const animationTimeout = setTimeout(() => {
                setRedPlanetsFade(true);
            }, 1000);

            return () => {
                clearTimeout(animationTimeout);
            };
        }

    }, [startAnimation]);


    // SECOND ANIMATIONS START

    useEffect(() => {
        if (endAnimation) {
            const animationTimeout = setTimeout(() => {
                setStartSecondAnimation(true);
            }, 5000);

            return () => {
                clearTimeout(animationTimeout);
            };
        }

    }, [endAnimation]);

    //   SECOND PLANETS ANIMATION
    useEffect(() => {
        if (endAnimation) {
            const animationTimeout = setTimeout(() => {
                setBluePlanetsFade(true);
            }, 1000);

            return () => {
                clearTimeout(animationTimeout);
            };
        }

    }, [endAnimation]);

    // removed display none from imageClasses
    const imageClasses = `image ${startAnimation ? 'rotate-fade' : ''} ${endAnimation ? 'display-none' : ''}`;
    const RedPlanetClasses = `red-fade-planets ${startAnimation ? ' fade-planets' : ''} ${endAnimation ? 'display-none' : ''}`;
    const secondImageClasses = `secondImage ${startSecondAnimation ? 'fade-animation' : ''} ${endSecondAnimation ? 'display-none' : ''}`;
    const bluePlanetsClasses = `blue-fade-planets ${startSecondAnimation ? 'fade-animation' : ''} ${endSecondAnimation ? 'display-none' : ''}}`;
    // const imageClasses = `image ${startAnimation ? '' : ''} ${endAnimation ? '' : ''}`;

    useEffect(() => {
        if (startAnimation) {
            const animationDuration = 5000;
            const animationEndTimeout = setTimeout(() => {
                setEndAnimation(true);
            }, animationDuration);

            return () => {
                clearTimeout(animationEndTimeout);
            };
        }
    }, [startAnimation]);
    useEffect(() => {
        if (startSecondAnimation) {
            const animationDuration = 5000;
            const animationEndTimeout = setTimeout(() => {
                setSecondEndAnimation(true);
            }, animationDuration);

            return () => {
                clearTimeout(animationEndTimeout);
            };
        }
    }, [startSecondAnimation]);

    return (
        // ${endAnimation ? 'display-none' : ''}
        <div className={`w-full justify-center flex relative top-[20vw] ${endAnimation ? 'hidden' : ''}`}>
            <div className='bg-lock'>
                <img className={`${RedPlanetClasses} relative height-[314.971px] z-0 top-[42vh] right-[36vw]`} src={redLeft} />
                <img className={`${RedPlanetClasses} w-[131.381px] h-[130.282px] relative top-[66vh] right-[20vw]`} src={redSmall} />
                <img src={redDot} className={`${RedPlanetClasses} relative w-71 h-70 left-[33vw] bottom-[28vh]`} />
                <img src={redDot} className={`${RedPlanetClasses} relative w-74 h-73 bottom-[16vh] right-[24vw]`} />
                <img
                    src={play}
                    alt="play"
                    className={`${imageClasses} z-0`}
                />
                <img className={`${RedPlanetClasses} relative z-0 left-[42.5vw]`} src={redRight} />
            </div>
            <div className='bg-unlock'>
                <img className={`${bluePlanetsClasses} relative left-[25vw]`} src={blueFull} />
                <img src={blueDot} className={`${bluePlanetsClasses} relative w-[68.791px] h-[67px] bottom-[16vh] right-[24vw]`} />
                <img
                    src={playUnlock}
                    alt="play"
                    className={`${secondImageClasses} z-0`}
                />
                <img className={`${bluePlanetsClasses} relative top-[50vh] right-[34vw] z-0`} src={blueFull} />
                <img src={blueSplash} className={`${bluePlanetsClasses} relative w-[125.983px] h-[125.31px] left-[3vw] top-[52vh]`} />
                <img src={blueDot} className={`${bluePlanetsClasses} relative w-[68.791px] h-[67px] left-[10vw] top-[32vw]`} />
                <img src={blueDot} className={`${bluePlanetsClasses} relative w-[39.016px] h-[38px] left-[16vw] T top-[19vw] `} />
                <img src={blueDot} className={`${bluePlanetsClasses} relative w-[39.016px] h-[38px] left-[24vw] top-[8vw]`} />
                <img className={`${bluePlanetsClasses} relative z-0 left-[29.5vw] bottom-[16vh]`} src={blueRight} />
            </div>
        </div>
    );
}

export default FirstAnimation;
