import { useState, useEffect } from "react";

export default function About() {
    const [midData, setMidData] = useState([]);
  const [toggleBg, setToggleBg] = useState(false);

  const data = [
    { 
    hash : 'gameDashboard',
    title: 'Gamedashboard',
    tagline: 'The All-In-One Game Analytics Platform',
    paragraph:
      'Gamedashboard is the all-in-one game analytics platform that gives you the insights you need to make the best decisions for your game. With Gamedashboard, you can track everything from NFT sales to token transactions to player engagement.',
    paragraph_bottom: 'Here are just a few of the things you can do with Gamedashboard:',
    top_list: [
      { data: "Track NFT sales and token transactions to see how your in-game economy is performing." },
      { data: "Monitor player engagement to see how long people are playing your game and what they're doing while they're playing." },
    ],
    bottom_list: [
      { data: "Identify trends in player behavior to see what's working and what's not." },
      { data: "Make informed decisions about your game's development and marketing based on data." },
    ],
  },
  { 
    hash : 'cex',
    title: 'Cex',
    tagline: '',
    paragraph:
      'Pixpel is launching a centralized exchange (CEX) that will revolutionize the way games are funded and get liquidity. Our CEX will have two sections: one for the most popular games with less risk, and another for new games with higher risk.',
    paragraph_bottom: '',
    top_list: [
      { data: "Crypto trade: This section will list the most popular and established games. Trading fees will be low and support will be excellent." },
      { data: "Token trade: This section will list recently released games. Game developers will have the chance to list their tokens in a market maker and maker taker exchange that will charge a high slippage price per transaction. All the games listed here will have the chance to upgrade to crypto trade after approving Pixpel criteria." },
    ],
    bottom_list: [
      { data: "" },
      { data: "" },
    ],
  },
  { 
    hash : 'launchpad1',
    title: 'Launchpad',
    tagline: '',
    paragraph:'Pixpel Launchpad is a platform that helps game developers launch their games and get funding from the community. The platform is divided into two sections: Rockets and Ships.',
    paragraph_bottom: '',
    top_list: [
      { data: "Rockets is a section where game developers can launch their game tokens. Game tokens are a type of cryptocurrency that can be used to purchase in-game items or to participate in the game's economy. When a game developer launches their game token on Pixpel Launchpad, they can get funding from the community by selling their tokens to investors" },
      { data: "Ships is a P2P Marketing section where influencers can offer videos and mentions on their social networks to games.When an influencer offers a video or mention to a game on Pixpel Launchpad, they can help the game to reach a wider audience and get more players, all this can be done without intermediaries and high fees." },
    ],
    bottom_list: [
      { data: "" },
      { data: "" },
    ],
  },
  { 
    hash : 'staking',
    title: 'Staking',
    tagline: '',
    paragraph:
      '',
    paragraph_bottom: '',
    top_list: [
      { data: "Pixpel is a revolutionary staking platform that transforms the way developers and players engage with digital assets. With a user-centric approach, Pixpel offers a seamless and efficient solution for creating staking pools, making it easier than ever for developers to participate in the staking economy. Simultaneously, players gain a low-cost and accessible pathway to join their favorite game pools, maximizing their rewards and gaming experiences. With a strong emphasis on trust and security, Pixpel ensures the safety of assets throughout the staking process." },
      { data: "" },
    ],
    bottom_list: [
      { data: "" },
      { data: "" },
    ],
  },
  { 
    hash : 'tokenroom',
    title: 'Token Room',
    tagline: '',
    paragraph:
      '',
    paragraph_bottom: '',
    top_list: [
      { data: "Simplify token creation with Pixpel's Token Room. We provide a streamlined platform for creating game tokens, offering recommendations based on tokenomics standards. Trust our security measures and partnerships with audit companies to ensure a safe and compliant token creation process. Join the Token Room and effortlessly create your game token with peace of mind." },
      { data: "" },
    ],
    bottom_list: [
      { data: "" },
      { data: "" },
    ],
  },
  { 
    hash : 'nftmarket',
    title: 'NFT Market',
    tagline: '',
    paragraph: "Pixpel NFT Marketplace is not your average marketplace. We offer a distinctive perspective on the world of crypto games that goes beyond just the price of NFTs. At Pixpel, we believe in showcasing the game dynamics, visuals, tokenomics, and all the essential information you need to dive into your favorite games.",
    paragraph_bottom: '',
    top_list: [
      { data: "A World of Information at Your Fingertips" },
      { data: "We understand the importance of having all the details at your fingertips. At Pixpel, you'll find comprehensive information about each game, including tokenomics, gameplay mechanics, and more. We empower you with the knowledge necessary to make the right choices and embark on your gaming adventures confidently." },
    ],
    bottom_list: [
      { data: "Discover a New Way to Explore Crypto Games" },
      { data: "Unlike traditional marketplaces, Pixpel provides a refreshing approach to exploring the world of crypto games. We offer a unique section that is truly awe-inspiring. Curious to see it for yourself? Come and visit us!" },
    ],
  },
  { 
    hash : 'nftfeature',
    title: 'NFT Features',
    tagline: '',
    paragraph: "Simplify token creation with Pixpel's Token Room. We provide a streamlined platform for creating game tokens, offering recommendations based on tokenomics standards. Trust our security measures and partnerships with audit companies to ensure a safe and compliant token creation process. Join the Token Room and effortlessly create your game token with peace of mind.",
    paragraph_bottom: '',
    top_list: [
      { data: "" },
      { data: "" },
    ],
    bottom_list: [
      { data: "" },
      { data: "" },
    ],
  },
  { 
    hash : 'p2pmarket',
    title: 'P2P Market',
    tagline: '',
    paragraph:
      "Simplify token creation with Pixpel's Token Room. We provide a streamlined platform for creating game tokens, offering recommendations based on tokenomics standards. Trust our security measures and partnerships with audit companies to ensure a safe and compliant token creation process. Join the Token Room and effortlessly create your game token with peace of mind.",
    paragraph_bottom: '',
    top_list: [
      { data: "" },
      { data: "" },
    ],
    bottom_list: [
      { data: "" },
      { data: "" },
    ],
  },
  { 
    hash : 'launchpad2',
    title: 'Launchpad',
    tagline: '',
    paragraph:
      'Welcome to Pixpel Launchpad, where innovative ideas and groundbreaking projects come to life in the world of NFTs. Our Launchpad provides a platform for creators and developers to launch their projects and captivate the NFT community.',
    paragraph_bottom: '',
    top_list: [
      { data: "Discover and Support Promising Rockets" },
      { data: "Explore a world of emerging talent and visionary ideas through Pixpel Launchpad. Stay ahead of the curve by discovering projects at their early stages, and become an early supporter of the ones that resonate with you. Pixpel Launchpad provides a platform for creators to gain exposure, engage with the community, and secure the necessary resources to bring their visions to life." },
    ],
    bottom_list: [
      { data: "Connect, Create, and Earn as an Influencer!" },
      { data: "Say goodbye to middlemen and connect directly with game developers. Discover exciting games, forge authentic connections, and showcase your creativity. Pixpel Launchpad works by providing a direct connection between influencers and game developers. As an influencer, you can explore the platform to discover exciting games that are actively seeking content creators like you Submit proposals, earn rewards, and become a catalyst for success in the gaming world. Join Pixpel Launchpad today and unlock new opportunities for your influencer journey!" },
    ],
  },
  { 
    hash : 'dex',
    title: 'Dex',
    tagline: '',
    paragraph:
      '',
    paragraph_bottom: '',
    top_list: [
      { data: "Pixpel's DEX is more than just an exchange - it's a gateway to the vast opportunities of the token economy. Whether you're a player seeking to expand your NFT collection or a developer looking for a streamlined funding process, our DEX empowers you to navigate the token landscape with confidence and ease." },
      { data: "Join Pixpel's DEX today and experience a new level of convenience, efficiency, and support in token transactions and funding rounds. Maximize your potential as a player or developer and embrace the future of the decentralized economy." },
    ],
    bottom_list: [
      { data: "" },
      { data: "" },
    ],
  },
  { 
    hash : 'inventory',
    title: 'Inventory',
    tagline: "Pixpel's NFT Inventory: Unleash the Power of Your NFTs",
    paragraph:
      '',
    paragraph_bottom: '',
    top_list: [
      { data: "Intuitive and Detailed: Get comprehensive information on your NFTs, tracking their evolution and performance in games." },
      { data: "Earning and Loss Assessment: Assess if your NFTs are generating profits or losses with detailed breakdowns." },
      {data: "Maximize Potential: Make informed decisions about holding, selling, or trading your NFTs to optimize your portfolio."},
      {data: "Streamlined User Experience: Enjoy a user-friendly interface for easy navigation and efficient management of your NFT collection."}
    ],
    bottom_list: [
      { data: "Unlock the potential of your NFTs with Pixpel's Inventory." },
      { data: "Visit us today and elevate your NFT experience." },
    ],
  },
  { 
    hash : 'wallet',
    title: 'Wallet',
    tagline: "Pixpel's Wallet: Control Earnings, Track NFT Prices",
    paragraph:
      '',
    paragraph_bottom: '',
    top_list: [
      { data: "Earnings Control: Take charge of your earnings, avoiding excessive fees when receiving and withdrawing funds from games." },
      { data: "Fee Avoidance: Say goodbye to burdensome fees associated with transactions. Pixpel's wallet ensures cost-effective financial management." },
      {data: "NFT Price Tracking: Stay informed with real-time NFT price tracking. Monitor investment performance and make informed decisions."},
      {data: "Organized Accounts: Keep finances organized with separate accounts for each game. Gain a clear overview of your financial status."}
    ],
    bottom_list: [
      { data: "Take control, track NFT prices, and streamline your financial management with Pixpel's Wallet." },
      { data: "Join us now and maximize your gaming investments." },
    ],
  },
];

useEffect(() => {
  localStorage.setItem('midData' , JSON.stringify(data));
},[]);

useEffect(() => {
  const storedData = localStorage.getItem('midData');
    setMidData(JSON.parse(storedData));
}, []);

  function handleToggle() {
    setToggleBg((prev) => !prev);
  }


  console.log(midData);

  return [midData, toggleBg, handleToggle];
}
